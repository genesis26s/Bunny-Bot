import discord
from discord import app_commands
from discord.ext import commands
from database import DatabaseManager
from config import Config
from utils import create_embed, error_embed, success_embed, format_coin, check_user_exists, random_chance
from datetime import datetime, timedelta
import random
import aiosqlite

class Economy(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.db: DatabaseManager = bot.db

    @app_commands.command(name="balance", description="Check your Bunny-Coin balance")
    async def balance(self, interaction: discord.Interaction, user: discord.Member = None):
        target = user or interaction.user
        user_data = await check_user_exists(self.db, target.id, target.name)
        embed = create_embed(f"🐰 {target.display_name}'s Wallet")
        embed.add_field(name="💰 Balance", value=format_coin(user_data['balance']), inline=True)
        embed.add_field(name="🏦 Bank", value=format_coin(user_data['bank_balance']), inline=True)
        embed.add_field(name="📊 Net Worth", value=format_coin(user_data['balance'] + user_data['bank_balance']), inline=True)
        embed.add_field(name="⭐ Level", value=f"{user_data['level']} (Prestige {user_data['prestige']})", inline=True)
        embed.add_field(name="💼 Job", value=f"ID: {user_data['job_id'] or 'Unemployed'}", inline=True)
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="daily", description="Claim your daily Bunny-Coins")
    @app_commands.checks.cooldown(1, 86400)
    async def daily(self, interaction: discord.Interaction):
        user_data = await check_user_exists(self.db, interaction.user.id, interaction.user.name)
        await self.db.add_balance(interaction.user.id, Config.DAILY_AMOUNT)
        await self.db.add_xp(interaction.user.id, 50)
        await self.db.add_transaction(interaction.user.id, "daily", Config.DAILY_AMOUNT, "Daily reward")
        embed = success_embed(f"You claimed {format_coin(Config.DAILY_AMOUNT)}!\n+50 XP")
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="weekly", description="Claim your weekly Bunny-Coins")
    @app_commands.checks.cooldown(1, 604800)
    async def weekly(self, interaction: discord.Interaction):
        user_data = await check_user_exists(self.db, interaction.user.id, interaction.user.name)
        await self.db.add_balance(interaction.user.id, Config.WEEKLY_AMOUNT)
        await self.db.add_xp(interaction.user.id, 200)
        await self.db.add_transaction(interaction.user.id, "weekly", Config.WEEKLY_AMOUNT, "Weekly reward")
        embed = success_embed(f"You claimed {format_coin(Config.WEEKLY_AMOUNT)}!\n+200 XP")
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="work", description="Work to earn Bunny-Coins")
    @app_commands.checks.cooldown(1, 3600)
    async def work(self, interaction: discord.Interaction):
        user_data = await check_user_exists(self.db, interaction.user.id, interaction.user.name)
        salary = random.randint(Config.WORK_MIN, Config.WORK_MAX)
        if user_data['job_id']:
            async with aiosqlite.connect(self.db.db_path) as db:
                cursor = await db.execute("SELECT base_salary, promotion_bonus, max_promotions FROM jobs WHERE job_id = ?", (user_data['job_id'],))
                job = await cursor.fetchone()
                if job:
                    bonus = job[1] * min(user_data['job_promotions'], job[2])
                    salary += job[0] + bonus
        await self.db.add_balance(interaction.user.id, salary)
        await self.db.add_xp(interaction.user.id, 25)
        await self.db.add_transaction(interaction.user.id, "work", salary, "Work salary")
        embed = success_embed(f"You worked hard and earned {format_coin(salary)}!\n+25 XP")
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="crime", description="Commit a crime for quick cash")
    @app_commands.checks.cooldown(1, 7200)
    async def crime(self, interaction: discord.Interaction):
        user_data = await check_user_exists(self.db, interaction.user.id, interaction.user.name)
        if random_chance(0.3):
            fine = random.randint(100, 500)
            await self.db.add_balance(interaction.user.id, -fine)
            embed = error_embed(f"🚔 You got caught and fined {format_coin(fine)}!")
        else:
            payout = random.randint(Config.CRIME_MIN, Config.CRIME_MAX)
            await self.db.add_balance(interaction.user.id, payout)
            await self.db.add_xp(interaction.user.id, 15)
            await self.db.add_transaction(interaction.user.id, "crime", payout, "Crime payout")
            embed = success_embed(f"😈 You committed a crime and got {format_coin(payout)}!\n+15 XP")
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="rob", description="Rob another player")
    @app_commands.checks.cooldown(1, 14400)
    async def rob(self, interaction: discord.Interaction, victim: discord.Member):
        if victim.id == interaction.user.id:
            return await interaction.response.send_message(embed=error_embed("You can't rob yourself!"), ephemeral=True)
        robber = await check_user_exists(self.db, interaction.user.id, interaction.user.name)
        target = await check_user_exists(self.db, victim.id, victim.name)
        if target['balance'] < 100:
            return await interaction.response.send_message(embed=error_embed("They don't have enough coins!"), ephemeral=True)
        if random_chance(Config.ROB_CHANCE):
            stolen = random.randint(1, int(target['balance'] * 0.3))
            await self.db.add_balance(interaction.user.id, stolen)
            await self.db.add_balance(victim.id, -stolen)
            await self.db.add_transaction(interaction.user.id, "rob", stolen, f"Robbed {victim.name}")
            embed = success_embed(f"🔫 You robbed {victim.display_name} for {format_coin(stolen)}!")
        else:
            fine = random.randint(50, 200)
            await self.db.add_balance(interaction.user.id, -fine)
            embed = error_embed(f"👮 You got caught and paid {format_coin(fine)} in fines!")
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="pay", description="Send Bunny-Coins to another player")
    async def pay(self, interaction: discord.Interaction, user: discord.Member, amount: int):
        if amount <= 0:
            return await interaction.response.send_message(embed=error_embed("Amount must be positive!"), ephemeral=True)
        sender = await check_user_exists(self.db, interaction.user.id, interaction.user.name)
        if sender['balance'] < amount:
            return await interaction.response.send_message(embed=error_embed("Not enough coins!"), ephemeral=True)
        await self.db.add_balance(interaction.user.id, -amount)
        await self.db.add_balance(user.id, amount)
        await self.db.add_transaction(interaction.user.id, "pay", -amount, f"Paid {user.name}")
        await self.db.add_transaction(user.id, "pay", amount, f"Received from {interaction.user.name}")
        embed = success_embed(f"💸 You sent {format_coin(amount)} to {user.display_name}!")
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="fish", description="Go fishing")
    @app_commands.checks.cooldown(1, 1800)
    async def fish(self, interaction: discord.Interaction):
        user_data = await check_user_exists(self.db, interaction.user.id, interaction.user.name)
        catches = [
            ("🗑️ Trash", 0, 0.3),
            ("🐟 Common Fish", 20, 0.4),
            ("🐠 Tropical Fish", 50, 0.2),
            ("🦈 Shark", 200, 0.08),
            ("🐋 Whale", 1000, 0.02),
        ]
        roll = random.random()
        cumulative = 0
        for name, value, chance in catches:
            cumulative += chance
            if roll <= cumulative:
                if value > 0:
                    await self.db.add_balance(interaction.user.id, value)
                    await self.db.add_xp(interaction.user.id, 20)
                    embed = success_embed(f"You caught a {name} worth {format_coin(value)}!\n+20 XP")
                else:
                    embed = error_embed(f"You caught {name}... worth nothing.")
                break
        else:
            embed = error_embed("The fish got away!")
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="hunt", description="Go hunting")
    @app_commands.checks.cooldown(1, 1800)
    async def hunt(self, interaction: discord.Interaction):
        catches = [
            ("🐇 Rabbit", 30, 0.35),
            ("🦌 Deer", 80, 0.3),
            ("🐗 Boar", 150, 0.2),
            ("🐻 Bear", 400, 0.1),
            ("🐉 Dragon", 2000, 0.05),
        ]
        roll = random.random()
        cumulative = 0
        for name, value, chance in catches:
            cumulative += chance
            if roll <= cumulative:
                await self.db.add_balance(interaction.user.id, value)
                await self.db.add_xp(interaction.user.id, 30)
                embed = success_embed(f"You hunted a {name} worth {format_coin(value)}!\n+30 XP")
                break
        else:
            embed = error_embed("You found nothing to hunt.")
        await interaction.response.send_message(embed=embed)

async def setup(bot):
    await bot.add_cog(Economy(bot))
