# 🐰 Bunny-Bot

A full-featured Economy Discord Bot with 70+ slash commands, SQLite database, dynamic market values, and comprehensive game systems.

## Features

- **Economy System**: Balance, daily/weekly rewards, work, crime, fishing, hunting
- **Banking**: Deposit, withdraw, interest, bank upgrades
- **Shop & Market**: Buy/sell items, player market with dynamic pricing
- **Inventory**: Use, equip, craft, inspect items
- **Enchantments**: Add magical effects to gear
- **Jobs**: 12 jobs with promotion system
- **Levels & Prestige**: XP system with prestige resets
- **Leaderboards**: Global and server-specific
- **Adventures**: Explore, dungeons, hidden treasures
- **Gambling**: Slots, dice, coinflip, lottery, blackjack
- **Pets**: Adopt, feed, train, battle
- **Properties**: Buy deeds, collect passive income
- **Mini-Games**: Quiz, trivia, guessing games
- **Perks**: Temporary buffs and bonuses
- **Potions**: Buy and drink stat-boosting potions
- **Admin Tools**: Coin management, user resets, stats

## Setup

1. Install dependencies:
```bash
pip install -r requirements.txt
```

2. Create `.env` file with your bot token:
```
BUNNY_BOT_TOKEN=your_token_here
```

3. Run the bot:
```bash
python main.py
```

## File Structure (22 files)

```
bunny_bot/
├── main.py           # Bot entry point
├── config.py         # Configuration settings
├── database.py       # SQLite database manager
├── utils.py          # Helper functions
├── requirements.txt  # Dependencies
├── .env.example      # Environment template
├── README.md         # This file
└── cogs/
    ├── __init__.py
    ├── economy.py      # 9 commands
    ├── banking.py      # 5 commands
    ├── shop.py         # 4 commands
    ├── market.py       # 5 commands
    ├── inventory.py    # 5 commands
    ├── items.py        # 1 command
    ├── jobs.py         # 5 commands
    ├── levels.py       # 4 commands
    ├── adventure.py    # 3 commands
    ├── gambling.py     # 5 commands
    ├── pets.py         # 5 commands
    ├── property.py     # 4 commands
    ├── minigames.py    # 2 commands
    ├── perks.py        # 3 commands
    ├── potions.py      # 3 commands
    ├── admin.py        # 6 commands
    └── help.py         # 2 commands
```

## Command Count: 71

## Dynamic Market Values

Item values change based on demand and supply:
- Buying increases demand → price rises
- Selling increases supply → price drops
- Values update automatically with each transaction
- Track trends with `/values`

## Database

SQLite database (`bunny_bot.db`) with tables:
- users, items, inventory, market_listings
- jobs, pets, properties, enchantments
- user_perks, perks_catalog, potions_catalog, user_potions
- transactions, cooldowns

## Bot Permissions Needed

- Send Messages
- Embed Links
- Read Message History
- Use Slash Commands
- Manage Messages (for admin)

## License

MIT
